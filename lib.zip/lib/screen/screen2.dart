import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uifirstdesign/screen/category.dart';
import 'package:uifirstdesign/screen/login.dart';

class Screen2 extends StatefulWidget {
  const Screen2({Key? key}) : super(key: key);

  @override
  State<Screen2> createState() => _Screen2State();
}

class _Screen2State extends State<Screen2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(children: [
            const SizedBox(height: 100),
            Text("Welcome",
                textAlign: TextAlign.center,
                style: GoogleFonts.ubuntu(fontSize: 36, color: Colors.black)),
            const SizedBox(
              height: 5,
            ),
            Text("Sign in  to start",
                textAlign: TextAlign.center,
                style:
                    GoogleFonts.ubuntu(fontSize: 14, color: Color(0xFF9D9D9D))),
            const SizedBox(
              height: 60,
            ),
            Center(
              child: SizedBox(
                  width: 280,
                  height: 43,
                  child: FloatingActionButton.extended(
                    icon: Image.asset(
                      'assets/google.png',
                      width: 28,
                      height: 29,
                    ),
                    label: Text(
                      "Continue with Google",
                      style:
                          GoogleFonts.ubuntu(fontSize: 16, color: Colors.black),
                    ),
                    onPressed: () {},
                    backgroundColor: Colors.white,
                  )),
            ),
            const SizedBox(
              height: 40,
            ),
            SizedBox(
              width: 280,
              height: 43,
              child: FloatingActionButton.extended(
                icon: Image.asset(
                  'assets/meta.png',
                  width: 28,
                  height: 29,
                ),
                label: Text(
                  "Continue with Meta",
                  style: GoogleFonts.ubuntu(fontSize: 16, color: Colors.white),
                ),
                onPressed: () {},
                backgroundColor: Color(0xff2079FF),
              ),
            ),
            const SizedBox(
              height: 40,
            ),
            Container(
              padding: const EdgeInsets.all(47),
            
              decoration: const ShapeDecoration(
                gradient: LinearGradient(
                       begin: Alignment(0.2, 0.5),
                    end: Alignment.topLeft,  
                    colors: [Color(0xFFA2B2FC), Color(0xFFFFF1BE)]),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                  topRight: Radius.circular(20.0),
                  topLeft: Radius.circular(20.0),
                )),
              ),
              child: Column(children: [
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    hintText: "Login id",
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    hintText: "password",
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    hintText: "password",
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
               Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                        child: Text(
                      "Haven't account?",
                      textAlign: TextAlign.center,
                      style: GoogleFonts.ubuntu(
                          fontSize: 16, color: Color(0xff424242)),
                    )),
                    TextButton(
                        child: Text(
                          "Sign up !",
                          style: GoogleFonts.ubuntu(
                              fontSize: 16, color: Color(0xff2079FF)),
                        ),
                        onPressed: () => {
                              Navigator.of(context).pop(MaterialPageRoute(
                                builder: (context) => Login(),
                              ))
                            }),
                  ],
                ),
                ElevatedButton(
                    child: Text("Conitnue"),
                    onPressed: () => {
                              Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => Comic(),
                              ))
                            },
                  
                    style: ElevatedButton.styleFrom(
                       fixedSize: const Size(450,40),
                        primary: const Color(0xFF424242),
                        textStyle: GoogleFonts.ubuntu(
                            fontSize: 16, color: Colors.white),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25),
                   )
                 )
               ),
              ]
              ),
            ),
          ]),
        ));
  }
}
