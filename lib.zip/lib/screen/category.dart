import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uifirstdesign/modals/gridmodal.dart';

class Comic extends StatefulWidget {
  const Comic({Key? key}) : super(key: key);

  @override
  State<Comic> createState() => _ComicState();
}

class _ComicState extends State<Comic> {
  List<Choice> choices = const <Choice>[
    const Choice(title: 'Action', image: "assets/Fire.png"),
    const Choice(title: 'Romance', image: "assets/Heart.png"),
    const Choice(title: 'Drama', image: "assets/Sneezing"),
    const Choice(title: 'Horror', image: "assets/face.png"),
    const Choice(title: 'Fantasy', image: "assets\Unicorn.png"),
    const Choice(title: 'Mistery', image: "assets\Camera.png"),
    const Choice(title: 'Magic', image: "assets\Crystal ball.png"),
    const Choice(title: 'Comedy', image: "assets\lau.png"),
    const Choice(title: 'Daily life', image: "assets\Calender.png"),
    const Choice(title: 'Pyschology', image: "assets\Clock.png"),
    const Choice(title: 'Adventure', image: "assets\Airplane.png"),
    const Choice(title: 'Thriller', image: "assets\coldface.png"),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(
                height: 50,
              ),
              Center(
                  child: Text("Let Us Know !",
                      style:
                          GoogleFonts.ubuntu(fontSize: 32, color: Colors.black))),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                width: 218,
                height: 36,
                child: Text(
                  "Choose Your genre find Out Favorite title here !",
                  overflow: TextOverflow.visible,
                  style:
                      GoogleFonts.ubuntu(fontSize: 16, color: Color(0XFF9D9D9D)),
                ),
              ),
              GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2),
                  itemCount: choices.length,
                  itemBuilder: (context, index) {
                    return Container(
                      height: 97,
                      width: 80,
                      color : Colors.red 
        
                    );
                  }
                )
            ],
          ),
        )
      );
  }
}
