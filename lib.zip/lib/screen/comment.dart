 // GridView.builder(
            //     gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            //         crossAxisCount: 2),
            //     itemCount: choices.length,
            //     itemBuilder: (context, index) {
            //       return Container(
            //         height: 97,
            //         width: 80,
            //         color

            //       );
            //      }
            // )
          ],