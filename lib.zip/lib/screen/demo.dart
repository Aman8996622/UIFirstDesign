import 'package:flutter/material.dart';

class Demo extends StatefulWidget {
  const Demo({Key? key}) : super(key: key);

  @override
  State<Demo> createState() => _DemoState();
}

class _DemoState extends State<Demo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
        backgroundColor: Colors.white,
        body: Center(
          child: Column(
            children: [
              Flexible(
                child: Container(
                  color: Colors.amber,
                ),
              ),
              Flexible(
                child: Container(
                  color: Colors.redAccent,
                ),
              ),
              Flexible(
                fit: FlexFit.loose,
                child: Container(
                   decoration: const ShapeDecoration(
                      color: Color(0xffA2B2FC),
                     shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                      topRight: Radius.circular(20.0),
                      topLeft: Radius.circular(20.0),
                      )
                     )
                   ) ,
                   child: Padding(
                     padding: const EdgeInsets.all(20),
                     child: Column(children: const [
                      
                       TextField(
                           decoration: InputDecoration(
                             border: UnderlineInputBorder()
                                        
                           ),
                                        
                       ),
                       SizedBox(height: 45,),
                       TextField(
                           decoration: InputDecoration(
                             border: UnderlineInputBorder()
                                        
                           ),
                                        
                        ),
                       
                      ]
                    ),
                   
                   ),
                      
                 ),  
               ), 
            ],
          ),
        )
        );
  }
}
