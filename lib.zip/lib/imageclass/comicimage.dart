class ComicImage {
  final String? image;
  final String? title;
  final String? subtile;
  final String? chapter;
  final String? noview;
  ComicImage({
    this.image,
    this.title,
    this.subtile,
    this.chapter,
    this.noview,
  });
}


