class Comicphoto {
  final String? title;
  final String? image;
  const 
  Comicphoto(
    {this.title, this.image});
}
 List<Comicphoto> choices = const <Comicphoto>[
    Comicphoto(title: 'Action', image: "assets/mangatanga.png"),
    Comicphoto(title: 'Romance', image: "assets/rezero.png"),
    Comicphoto(title: 'Drama', image: "assets/mangatanga.png"),
    Comicphoto(title: 'Horror', image: "assets/mangatanga.png"),
    Comicphoto(title: 'Fantasy', image: "assets/mangatanga.png"),
    Comicphoto(title: 'Mistery', image: "assets/mangatanga.png"),
   
];