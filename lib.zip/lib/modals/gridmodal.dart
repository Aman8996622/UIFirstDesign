

class Choice {
 
  final String? title;
  final String? image;
  const Choice(
    {
      this.title, 
      this.image
     }
   );
}


  
  
