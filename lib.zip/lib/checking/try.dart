// import 'package:flutter/src/foundation/key.dart';
// import 'package:flutter/src/widgets/framework.dart';
// import 'package:material_floating_search_bar/material_floating_search_bar.dart';

// class search extends StatefulWidget {
//   const search({Key? key}) : super(key: key);

//   @override
//   State<search> createState() => _searchState();
// }

// class _searchState extends State<search> {
//   @override
//   Widget build(BuildContext context) {
//     return FloatingSearchBar(
//       hint: 'seach ..'
//       scroll)
//   }
// }